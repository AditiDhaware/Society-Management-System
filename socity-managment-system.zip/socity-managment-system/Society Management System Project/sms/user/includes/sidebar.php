<div id="leftsidebar" class="sidebar">
        <div class="sidebar-scroll">
            <nav id="leftsidebar-nav" class="sidebar-nav">
                <ul id="main-menu" class="metismenu">
                    <li class="heading">Main</li>
                    <li><a href="dashboard.php"><i class="icon-home"></i><span>Dashboard</span></a></li>
                    
                    <li class="middle">
                        <a href="view-bill.php"><i class="icon-diamond"></i><span>View Bill</span></a>
                      
                    </li>
                  
                   
                    <li>
                        <a href="view-visitorlist.php"><i class="icon-users"></i><span>Visitors</span></a>
                        
                    </li>
                    <li>
                        <a href="#Tables" class="has-arrow"><i class="icon-tag"></i><span>Complain</span></a>
                        <ul>
                            <li><a href="raise-complain.php">Raise Complain</a></li>
                            <li><a href="complain-status.php">Complain Status</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="search-visitor.php"><i class="icon-magnifier"></i><span>Search</span></a>
                       
                    </li>
                    <li>
                        <a href="visitor-bwdates.php"><i class="icon-folder"></i><span>Report</span></a>
                       
                    </li>
                                          
                   
                </ul>
            </nav>
        </div>
    </div>